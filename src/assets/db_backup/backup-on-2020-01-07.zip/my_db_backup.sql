#
# TABLE STRUCTURE FOR: Gamedata
#

DROP TABLE IF EXISTS `Gamedata`;

CREATE TABLE `Gamedata` (
  `idgamedata` int(11) NOT NULL AUTO_INCREMENT,
  `dateofCreated` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `idAppUser` int(11) NOT NULL,
  `file_storage` varchar(512) NOT NULL,
  PRIMARY KEY (`idgamedata`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `Gamedata` (`idgamedata`, `dateofCreated`, `idAppUser`, `file_storage`) VALUES (1, '2019-11-29 10:18:20.123300', 4, 'http://localhost/unityibm/upload/Game/profile_20191129111820.json');
INSERT INTO `Gamedata` (`idgamedata`, `dateofCreated`, `idAppUser`, `file_storage`) VALUES (2, '2019-12-20 09:40:55.958055', 11, 'http://localhost:8000/upload/Game/profile_20191220094055.json');
INSERT INTO `Gamedata` (`idgamedata`, `dateofCreated`, `idAppUser`, `file_storage`) VALUES (3, '2019-12-20 09:41:40.681214', 11, 'http://localhost:8000/upload/Game/profile_20191220094140.json');


#
# TABLE STRUCTURE FOR: all_asset_bundles
#

DROP TABLE IF EXISTS `all_asset_bundles`;

CREATE TABLE `all_asset_bundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `tags` varchar(32) NOT NULL,
  `assetBundlesFileName` varchar(64) NOT NULL,
  `assetBundlesFilePath` varchar(512) NOT NULL,
  `size` varchar(64) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateOfUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `all_asset_bundles` (`id`, `title`, `tags`, `assetBundlesFileName`, `assetBundlesFilePath`, `size`, `dateOfCreated`, `dateOfUpdate`) VALUES (6, 'asset bundles', 'models', 'prefab_models.assetbundles', 'http://localhost:8000/upload/Assetbundles/prefab_models.assetbundles', '0', '2020-01-07 09:26:11', '2020-01-07 09:26:11');


#
# TABLE STRUCTURE FOR: appusers
#

DROP TABLE IF EXISTS `appusers`;

CREATE TABLE `appusers` (
  `idAppUser` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `userName` varchar(128) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(256) NOT NULL,
  `dateofbirth` varchar(64) NOT NULL,
  `verification_hash` varchar(512) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `categories` enum('basic','premium') DEFAULT NULL,
  `gender` enum('male','female') NOT NULL,
  `dateofCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idAppUser`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `appusers` (`idAppUser`, `name`, `userName`, `email`, `password`, `dateofbirth`, `verification_hash`, `status`, `categories`, `gender`, `dateofCreated`) VALUES (11, '', 'amjad', 'amjadkhan89@hotmail.com', '$2y$10$bZnieaZ2kdtbnBaA.Dm2..hRV4pzIg7NWcDGEO4.sAl4vYUNfd85O', '', 'nxY3UqBoIZNf8PXvLr79JTiR4KWQjaCdwbkuDOg0', 1, NULL, 'male', '2019-12-20 09:34:15');


#
# TABLE STRUCTURE FOR: asset_management_animations
#

DROP TABLE IF EXISTS `asset_management_animations`;

CREATE TABLE `asset_management_animations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `tags` varchar(32) NOT NULL,
  `animationFileName` varchar(64) NOT NULL,
  `animationFilePath` varchar(512) NOT NULL,
  `size` varchar(32) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: asset_management_materials
#

DROP TABLE IF EXISTS `asset_management_materials`;

CREATE TABLE `asset_management_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `tags` varchar(32) NOT NULL,
  `materialFileName` varchar(64) NOT NULL,
  `materialFilePath` varchar(512) NOT NULL,
  `size` varchar(32) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: asset_management_models
#

DROP TABLE IF EXISTS `asset_management_models`;

CREATE TABLE `asset_management_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tags` varchar(64) NOT NULL,
  `title` varchar(64) NOT NULL,
  `model_fileName` varchar(64) NOT NULL,
  `model_url` varchar(512) NOT NULL,
  `size` varchar(64) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idCategory` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `asset_management_models` (`id`, `tags`, `title`, `model_fileName`, `model_url`, `size`, `status`, `date_created`, `idCategory`) VALUES (1, 'cars', '3d model for car', 'Screen_Shot_2019-11-24_at_12.56.08_PM.png', 'http://localhost/unityibm/upload/3DModules/Screen_Shot_2019-11-24_at_12.56.08_PM.png', '138.76', 'active', '2019-11-25 04:08:02', 1);
INSERT INTO `asset_management_models` (`id`, `tags`, `title`, `model_fileName`, `model_url`, `size`, `status`, `date_created`, `idCategory`) VALUES (2, '#tree', '3d model for tree', 'Screen_Shot_2019-11-25_at_12.11.47_PM.png', 'http://localhost/unityibm/upload/3DModules/Screen_Shot_2019-11-25_at_12.11.47_PM.png', '18.15', 'active', '2019-11-25 04:14:43', 2);
INSERT INTO `asset_management_models` (`id`, `tags`, `title`, `model_fileName`, `model_url`, `size`, `status`, `date_created`, `idCategory`) VALUES (3, 'cars', '3d model for car', 'Screen_Shot_2019-11-25_at_12.11.47_PM.png', 'http://localhost/unityibm/upload/3DModules/Screen_Shot_2019-11-25_at_12.11.47_PM.png', '18.15', 'active', '2019-11-25 04:16:57', 1);


#
# TABLE STRUCTURE FOR: asset_management_music_track
#

DROP TABLE IF EXISTS `asset_management_music_track`;

CREATE TABLE `asset_management_music_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `tags` varchar(64) NOT NULL,
  `musicFileName` varchar(64) NOT NULL,
  `musicFilePath` varchar(512) NOT NULL,
  `size` varchar(32) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: asset_management_shaders
#

DROP TABLE IF EXISTS `asset_management_shaders`;

CREATE TABLE `asset_management_shaders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `tags` varchar(32) NOT NULL,
  `shaderFileName` varchar(64) NOT NULL,
  `shaderFilePath` varchar(512) NOT NULL,
  `size` varchar(64) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: asset_management_skybox
#

DROP TABLE IF EXISTS `asset_management_skybox`;

CREATE TABLE `asset_management_skybox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `tags` varchar(32) NOT NULL,
  `skyBoxFileName` varchar(64) NOT NULL,
  `skyBoxFilePath` varchar(512) NOT NULL,
  `size` varchar(64) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: asset_management_sound_effects
#

DROP TABLE IF EXISTS `asset_management_sound_effects`;

CREATE TABLE `asset_management_sound_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `tags` varchar(64) NOT NULL,
  `soundsFileName` varchar(128) NOT NULL,
  `soundsFilePath` varchar(512) NOT NULL,
  `size` varchar(64) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category3Dmodel
#

DROP TABLE IF EXISTS `category3Dmodel`;

CREATE TABLE `category3Dmodel` (
  `idCategory` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` enum('Active','InActive') DEFAULT NULL,
  `dateofCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idCategory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: forget_user_password
#

DROP TABLE IF EXISTS `forget_user_password`;

CREATE TABLE `forget_user_password` (
  `idForgetPassword` int(11) NOT NULL AUTO_INCREMENT,
  `forget_password_hash` varchar(512) NOT NULL,
  `idAppUser` int(11) NOT NULL,
  `dateofCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idForgetPassword`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ibm_storage
#

DROP TABLE IF EXISTS `ibm_storage`;

CREATE TABLE `ibm_storage` (
  `storageId` int(11) NOT NULL AUTO_INCREMENT,
  `storageTitle` varchar(50) NOT NULL,
  `storageName` varchar(64) NOT NULL,
  `storagePath` varchar(512) NOT NULL,
  `dateOfCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateOfUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`storageId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `ibm_storage` (`storageId`, `storageTitle`, `storageName`, `storagePath`, `dateOfCreated`, `dateOfUpdate`) VALUES (5, 'test', '1.jpeg', 'http://localhost:8000/upload/Ibm/1.jpeg', '2020-01-07 10:54:24', '2020-01-07 10:54:24');


#
# TABLE STRUCTURE FOR: super_admin
#

DROP TABLE IF EXISTS `super_admin`;

CREATE TABLE `super_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(128) NOT NULL,
  `roles` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `super_admin` (`id`, `name`, `email`, `password`, `roles`, `date_created`, `date_modified`) VALUES (1, 'amjad', 'superadmin@dbis.com', '$2y$10$MZBNM3TWD.h2aN1vq4MBXuYiw.KjIbuZbB33a5jV9KERpHttZt76y', 1, '2019-12-23 06:12:00', '2019-12-23 06:12:00');
INSERT INTO `super_admin` (`id`, `name`, `email`, `password`, `roles`, `date_created`, `date_modified`) VALUES (3, 'logan', 'ums@dbis.com', '$2y$10$Z9ij3nWZtXaDVZj1cufnzeFYXFGSG6JRfGHNmQRSLMjtItfWfmupe', 2, '2019-12-23 06:41:20', '2019-12-23 06:41:20');


